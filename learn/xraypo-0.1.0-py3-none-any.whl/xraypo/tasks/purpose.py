"""Purpose 任务 - 分析文件作用"""

from xraypo.config import AnalysisUnit
from xraypo.tasks.base import AnalysisTask, TaskContext


class PurposeTask(AnalysisTask):
    """分析文件/组的作用和目的"""

    name = "purpose"
    suffix = ".purpose.md"

    def requires_source(self) -> bool:
        return True

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        # 使用 @相对路径 语法引用文件
        if context.base_dir:
            file_refs = " ".join(
                f"@{self.relative_path(abs_path, context.base_dir)}" for abs_path in sorted(unit.files.values())
            )
        else:
            # 降级到绝对路径
            file_refs = " ".join(f"@{abs_path}" for abs_path in sorted(unit.files.values()))

        if unit.type == "file":
            return f"""帮我理解 {file_refs} 这个文件的主要功能"""
        else:
            return f"""帮我理解 {file_refs} 这些文件的主要功能"""
