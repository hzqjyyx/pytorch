# PyTorch ATen 伪代码规范 (TorchPseudo DSL)

> **目标**: 将PyTorch C++/CUDA代码转换为易读的伪代码，专注于算法本质

---

## 1. 整体结构

每个函数用以下模板：

```
--------------------------------
函数名
来源: 文件路径
--------------------------------

【签名】
    函数签名，使用类型注解

【算法】
    核心算法逻辑

【并行模式】(可选)
    并行策略描述

【备注】(可选)
    特殊说明
```

---

## 2. 类型系统

### 2.1 Tensor类型

```
Tensor[形状, dtype]
```

**形状语法**:
| 语法 | 含义 | 示例 |
|------|------|------|
| `N` | 具名维度 | `Tensor[B, C, H, W]` |
| `*` | 任意前缀维度 | `Tensor[*, C]` |
| `*D` | 命名的任意维度组 | `Tensor[*D, C]` |
| `?` | 可选维度 | `Tensor[?, C, H, W]` |
| `N=值` | 约束值 | `Tensor[C=3, H, W]` |

**dtype语法**: `float`, `float32`, `int`, `int64`, `bool`, `same`

### 2.2 其他类型

```
alpha: Scalar              # 任意标量
threshold: Scalar[float]   # 浮点标量
dim: int                   # 整数
mode: "none" | "tanh"      # 枚举
```

---

## 3. 算法表达

```python
# 条件
y = where(x > 0, x, x * slope)

# 数学函数
erf(x), tanh(x), exp(x), log(x), sigmoid(x), softmax(x, dim)

# 常量
PI, SQRT2, √(2/π)

# 索引
x[i], x[i:j], x[..., -1], x[indices]
x.size(0), x.dim

# 归约
max(x, dim), sum(x, dim)
```

---

## 4. 并行模式

| 模式 | 含义 |
|------|------|
| `elementwise` | 每元素独立 |
| `parallel_for i in range(N)` | 并行循环 |
| `reduce(dim, op)` | 归约操作 |
| `warp_reduce(op)` | Warp级归约 |
| `block_reduce(op)` | Block级归约 |
| `atomic_add` | 原子加 |

---

## 5. 转换原则

### 5.1 核心原则：简化但保留语义

**✅ 做**：简化语法、去除噪音、抽象类型
**❌ 不做**：展开函数调用、重写实现逻辑

```
原始代码:
    cdist_stub(device1, result, tensor1_expanded, tensor2_expanded, p);

✅ 正确 - 保留调用:
    cdist_stub(result, x1_flat, x2_flat, p)

❌ 错误 - 展开实现:
    for i in range(R1):
        for j in range(R2):
            result[i,j] = norm(x1[i] - x2[j], p)
```

再举一个例子
```
原始代码:
    check_inputs(XQ, WQ, x_scale, w_scale, bias, out);

    dispatch_fp8_rowwise_kernel_on_bias_dtype(XQ, WQ, x_scale, w_scale, bias, use_fast_accum, out);

✅ 正确 - 保留调用:
    check_inputs(XQ, WQ, x_scale, w_scale, bias, out)
    dispatch_fp8_rowwise_kernel_on_bias_dtype(XQ, WQ, x_scale, w_scale, bias, use_fast_accum, out);
（看起来是跟原始代码一样，但这很合理，因为就是很简单）

❌ 错误 - 展开实现:
# Step 0: 输入验证
assert XQ.is_cuda() and XQ.dtype in [float8_e4m3fn, float8_e5m2]
assert WQ.is_cuda() and WQ.dtype == float8_e4m3fn
assert x_scale.dtype == float and x_scale.shape == [M, 1]
assert w_scale.dtype == float and w_scale.shape == [1, N]
assert out.dtype == bfloat16 and out.shape == [M, N]

if bias is not None:
    assert bias.dtype in [float, bfloat16]
    assert bias.shape == [N]

# Step 1: Workaround for M不是256的倍数的padding
if M % 256 != 0:
    padded_M = ceil(M / 256) * 256
    padded_x_scale = new_empty(padded_M, 1)
    padded_x_scale[:M, :] = x_scale
    x_scale = padded_x_scale
...
```

**例外：简单 elementwise 公式**

对于纯数学的 elementwise 操作，可以直接写公式：
```
# GELU: 原始调用 GeluKernel，但公式就是核心
y = x * 0.5 * (1 + erf(x * √0.5))

# Leaky ReLU: 原始调用 leaky_relu_stub，但公式简单
y = where(x > 0, x, x * slope)
```

因为这类操作的 kernel 内部就是这个公式，没有额外逻辑。

### 5.2 忽略的内容

- `backward` 相关函数
- `#ifdef USE_ROCM` 分支
- 注册宏 (`TORCH_IMPL_FUNC`, `TORCH_META_FUNC`, `DEFINE_DISPATCH`)
- 类型分发 (`AT_DISPATCH_*`)
- 错误检查 (`TORCH_CHECK`)
- 设备类型判断 (`device1 == kCPU || device1 == kCUDA`)

---

## 6. 示例

### 示例1: GELU

```
--------------------------------
gelu:
来源: Activation.cpp
--------------------------------

【签名】
    gelu(x: Tensor[*D, float], approximate: "none"|"tanh" = "none") -> Tensor[*D]

【算法】
    match approximate:
        "none":
            y = x * 0.5 * (1 + erf(x * √0.5))
        "tanh":
            β = √(2/π)
            y = x * 0.5 * (1 + tanh(β * (x + 0.044715 * x³)))

【并行模式】
    elementwise
```

### 示例2: Leaky ReLU

```
--------------------------------
leaky_relu:
来源: Activation.cpp
--------------------------------

【签名】
    leaky_relu(x: Tensor[*D], negative_slope: Scalar = 0.01) -> Tensor[*D]

【算法】
    y = where(x > 0, x, x * negative_slope)

【并行模式】
    elementwise
```

### 示例3: PReLU

```
--------------------------------
prelu:
来源: Activation.cpp
--------------------------------

【签名】
    prelu(x: Tensor[*D], weight: Tensor[1] | Tensor[C]) -> Tensor[*D]

    约束:
    - weight.numel == 1 或 weight.numel == x.size(1)
    - weight.dim <= 1

【算法】
    # 调整 weight 形状以便广播
    if x.dim != weight.dim:
        dim_w = [1] * x.dim
        if x.dim > 1:
            dim_w[1] = weight.numel
        weight = weight.reshape(dim_w)

    return _prelu_kernel(x, weight)

【备注】
    - _prelu_kernel: 实际计算 where(x > 0, x, x * weight)
```

### 示例4: SoftMax (复杂CUDA例子)

```
--------------------------------
softmax:
来源: cuda/SoftMax.cu
--------------------------------

【签名】
    softmax(x: Tensor[*, dim_size, *], dim: int) -> Tensor[*, dim_size, *]

【算法】
    # 沿 dim 维度计算 softmax
    # 将输入看作 (outer, dim_size, inner) 三维

    parallel_for outer in range(outer_size):
        parallel_for inner in range(inner_size):

            # Step 1: 找最大值 (数值稳定性)
            max_val = reduce(x[outer, :, inner], op=max)

            # Step 2: 计算 exp 和 sum
            sum_exp = reduce(exp(x[outer, :, inner] - max_val), op=sum)

            # Step 3: 归一化
            for d in range(dim_size):
                y[outer, d, inner] = exp(x[outer, d, inner] - max_val) / sum_exp

【并行模式】
    grid: (outer_size, inner_blocks)
    block: (dim_threads, inner_threads)

    - outer 维度: gridDim.x 并行
    - inner 维度: gridDim.y * blockDim.y 并行
    - dim 维度: blockDim.x 并行归约

    优化:
    - shared_memory: 存储归约中间结果
    - block_reduce: 跨 threadIdx.x 归约 max 和 sum

【备注】
    - 有两种kernel: Spatial (inner_size大) 和 Regular (dim_size大)
    - 使用 accscalar_t 进行累加以保持精度
```

### 示例5: Log SoftMax

```
--------------------------------
log_softmax:
来源: cuda/SoftMax.cu
--------------------------------

【签名】
    log_softmax(x: Tensor[*, dim_size, *], dim: int) -> Tensor[*, dim_size, *]

【算法】
    max_val = reduce(x, dim=dim, op=max)
    sum_exp = reduce(exp(x - max_val), dim=dim, op=sum)
    logsum = log(sum_exp)

    y = x - max_val - logsum

【备注】
    - 与 softmax 类似，但更数值稳定
    - 公式: log(softmax(x)) = x - max - log(sum(exp(x - max)))
```

### 示例6: Index Select Backward (复杂索引操作)

```
--------------------------------
indexing_backward:
来源: cuda/Indexing.cu
--------------------------------

【签名】
    indexing_backward(
        sorted_indices: Tensor[N, int64],    # 已排序
        orig_indices: Tensor[N, int64],
        grad_output: Tensor[outer, N, stride],
        accumulate: bool
    ) -> Tensor[?, stride]

【算法】
    parallel_for idx in range(N):
        # 只处理每组相同索引的第一个
        if idx == 0 or sorted_indices[idx] != sorted_indices[idx-1]:

            num_dups = count_consecutive_equal(sorted_indices, idx)
            weight_row = sorted_indices[idx]

            if not accumulate:
                # 只保留最后一个
                src_row = orig_indices[idx + num_dups - 1]
                grad_weight[weight_row, :] = grad_output[src_row, :]
            else:
                # 累加所有重复项
                for dup in range(num_dups):
                    src_row = orig_indices[idx + dup]
                    grad_weight[weight_row, :] += grad_output[src_row, :]

【并行模式】
    grid: (ceil(N/block_y), ceil(stride/warp_size), outer_dim)
    block: (warp_size, 4)

    优化:
    - 小 num_dups: 单线程顺序累加
    - 大 num_dups: warp_reduce 并行累加
```

### 示例7: cdist (成对距离计算)

```
--------------------------------
cdist_impl:
来源: Distance.cpp
--------------------------------

【签名】
    cdist_impl(
        x1: Tensor[*B, R1, C, float],    # batch可广播，R1行，C列
        x2: Tensor[*B, R2, C, float],    # batch可广播，R2行，C列
        p: float,                         # Lp范数，p >= 0
        compute_mode: 0|1|2 = 0           # 0=自动, 1=强制矩阵乘法, 2=禁用矩阵乘法
    ) -> Tensor[*B, R1, R2]

    约束:
    - x1.size(-1) == x2.size(-1)         # 列数必须相同
    - p >= 0

【算法】
    # Step 1: Batch广播并展平
    B = broadcast(x1.shape[:-2], x2.shape[:-2])
    x1_flat = x1.expand(*B, R1, C).reshape(prod(B), R1, C)
    x2_flat = x2.expand(*B, R2, C).reshape(prod(B), R2, C)

    # Step 2: 计算成对距离
    if R1 == 0 or R2 == 0 or prod(B) == 0:
        return empty(*B, R1, R2)

    if C == 0:
        return zeros(*B, R1, R2)

    if p == 2 and (mode == 1 or (mode == 0 and (R1 > 25 or R2 > 25))):
        # p=2 且行数较大时，用矩阵乘法优化
        if prod(B) == 1:
            dist = _euclidean_dist(x1, x2)
        else:
            dist = _euclidean_dist(x1_flat, x2_flat)
        result = dist.reshape(*B, R1, R2)
    else:
        # 通用 Lp 距离
        result = empty(*B, R1, R2)
        cdist_stub(result, x1_flat, x2_flat, p)
        result = result.reshape(*B, R1, R2)

    return result

【备注】
    - cdist_stub: 实际的成对距离计算kernel，见 Distance.h
    - _euclidean_dist: 欧氏距离的矩阵乘法优化实现
```

### 示例8: euclidean_dist (欧氏距离矩阵乘法优化)

```
--------------------------------
_euclidean_dist:
来源: Distance.cpp
--------------------------------

【签名】
    _euclidean_dist(
        x1: Tensor[*, R1, C],
        x2: Tensor[*, R2, C]
    ) -> Tensor[*, R1, R2]

【算法】
    # 使用恒等式: ||a-b||² = ||a||² + ||b||² - 2<a,b>

    x1_norm = sum(x1², dim=-1, keepdim=True)   # [*, R1, 1]
    x2_norm = sum(x2², dim=-1, keepdim=True)   # [*, R2, 1]

    # 构造增广矩阵以便用单次 matmul 计算
    x1_ = cat([-2*x1, x1_norm, ones_like(x1_norm)], dim=-1)  # [*, R1, C+2]
    x2_ = cat([x2, ones_like(x2_norm), x2_norm], dim=-1)     # [*, R2, C+2]

    # matmul: [*, R1, C+2] @ [*, C+2, R2] -> [*, R1, R2]
    # = -2*x1·x2ᵀ + x1_norm + x2_norm
    result = x1_ @ x2_.transpose(-1, -2)

    return clamp(result, min=0).sqrt()

【备注】
    - 利用矩阵乘法替代显式循环，在GPU上更高效
    - clamp(min=0) 处理浮点误差导致的微小负数
```
