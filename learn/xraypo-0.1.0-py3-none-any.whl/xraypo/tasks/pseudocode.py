"""Pseudocode 任务 - 生成伪代码"""

import os

from xraypo.config import AnalysisUnit
from xraypo.tasks.base import AnalysisTask, TaskContext


class PseudocodeTask(AnalysisTask):
    """将代码翻译为伪代码"""

    name = "pseudocode"
    suffix = ".pseudo.md"

    def requires_source(self) -> bool:
        return True

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        # 使用 @相对路径 语法引用文件
        if context.base_dir:
            file_refs = " ".join(
                f"@{self.relative_path(abs_path, context.base_dir)}" for abs_path in sorted(unit.files.values())
            )
        else:
            # 降级到绝对路径
            file_refs = " ".join(f"@{abs_path}" for abs_path in sorted(unit.files.values()))

        file_name = os.path.join(os.path.dirname(__file__), "prompt_pseudo_aten.md")
        with open(file_name, "r") as f:
            aten_rule = f.read()

        return f"""{aten_rule}
---
根据以上规则，将 {file_refs} 翻译为伪代码。"""
