from xraypo.tasks.base import AnalysisTask, TaskContext
from xraypo.tasks.folder_summary import FolderSummaryTask
from xraypo.tasks.pseudocode import PseudocodeTask
from xraypo.tasks.purpose import PurposeTask

# 任务注册表
TASK_REGISTRY: dict[str, type[AnalysisTask]] = {
    "purpose": PurposeTask,
    "pseudocode": PseudocodeTask,
    "folder_summary": FolderSummaryTask,
}

__all__ = [
    "AnalysisTask",
    "TaskContext",
    "PurposeTask",
    "PseudocodeTask",
    "FolderSummaryTask",
    "TASK_REGISTRY",
]
