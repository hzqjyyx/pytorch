"""FolderSummary 任务 - 文件夹汇总"""

from xraypo.config import AnalysisUnit
from xraypo.tasks.base import AnalysisTask, TaskContext


class FolderSummaryTask(AnalysisTask):
    """基于子单元分析结果汇总文件夹"""

    name = "folder_summary"
    suffix = ".md"

    def requires_source(self) -> bool:
        return False  # 输入是子单元的分析结果，不是源码

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        if not context.results_dir:
            return "错误：缺少子单元分析结果目录"

        # 使用 @相对路径 语法引用子单元的分析结果
        if context.base_dir:
            rel_path = self.relative_path(context.results_dir, context.base_dir)
            file_refs = f"@{rel_path}"
        else:
            # 降级到绝对路径
            file_refs = f"@{context.results_dir}"

        return f"""基于 {file_refs} 目录下的分析结果，生成该目录的汇总。

请用中文回答，包含以下内容：
1. 目录概述：这个目录的整体作用
2. 模块组成：主要包含哪些子模块，各自负责什么
3. 模块间关系：这些模块之间如何协作
4. 架构特点：有什么设计模式或架构特点
"""
