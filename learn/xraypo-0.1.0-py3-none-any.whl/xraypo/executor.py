"""执行引擎 - 并行执行分析任务"""

import asyncio

import tiktoken

from xraypo.cache import CacheManager
from xraypo.config import AnalysisUnit, Config, TaskResult
from xraypo.llm import LLMError, call_claude
from xraypo.model_selector import select_model
from xraypo.tasks import TASK_REGISTRY, AnalysisTask
from xraypo.tasks.base import TaskContext

# Claude 用 cl100k_base 编码
_encoder = tiktoken.get_encoding("cl100k_base")


class Executor:
    """并行执行引擎"""

    def __init__(self, config: Config):
        self.config = config
        self.cache = CacheManager(config.target)
        self.semaphore = asyncio.Semaphore(config.max_workers)
        # 统计
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.total = 0
        self.total_tokens = 0

    async def execute(self, units: list[AnalysisUnit]) -> list[TaskResult]:
        """执行所有任务"""
        # 分离 folder 和非 folder 单元
        file_units = [u for u in units if u.type != "folder"]
        folder_units = [u for u in units if u.type == "folder"]

        # 加载任务
        tasks = [TASK_REGISTRY[name]() for name in self.config.tasks if name in TASK_REGISTRY]
        source_tasks = [t for t in tasks if t.requires_source()]
        folder_tasks = [t for t in tasks if not t.requires_source()]

        self.total = len(file_units) * len(source_tasks) + len(folder_units) * len(folder_tasks)
        print(f"共 {self.total} 个任务待执行")

        results: list[TaskResult] = []

        # 第一阶段：执行 file/group 单元的任务
        if source_tasks:
            coros = [self._run_unit_tasks(u, source_tasks) for u in file_units]
            batch_results = await asyncio.gather(*coros)
            for r in batch_results:
                results.extend(r)

        # 第二阶段：自底向上执行 folder 单元的任务
        if folder_tasks and folder_units:
            # 按深度排序（深的先执行）
            sorted_folders = sorted(folder_units, key=lambda u: -u.id.count("/"))
            for folder in sorted_folders:
                folder_results = await self._run_unit_tasks(folder, folder_tasks)
                results.extend(folder_results)

        print(f"\n完成: {self.completed}, 跳过: {self.skipped}, 失败: {self.failed}")
        print(f"总输出 tokens: {self.total_tokens:,}")
        return results

    async def _run_unit_tasks(self, unit: AnalysisUnit, tasks: list[AnalysisTask]) -> list[TaskResult]:
        """执行单个单元的所有任务"""
        results = []
        for task in tasks:
            result = await self._run_single_task(unit, task)
            results.append(result)
        return results

    async def _run_single_task(self, unit: AnalysisUnit, task: AnalysisTask) -> TaskResult:
        """执行单个任务"""
        # 计算输出路径
        output_path = unit.output_dir / task.output_filename(unit)

        # 检查缓存（force 模式跳过）
        if not self.config.force and self.cache.should_skip(unit, task.name, output_path):
            self.skipped += 1
            self._print_progress(unit.id, task.name, "跳过", tokens=0)
            return TaskResult(
                unit_id=unit.id,
                task_name=task.name,
                success=True,
                output_path=None,
                error=None,
            )

        async with self.semaphore:
            try:
                # 构建上下文
                context = TaskContext(
                    results_dir=unit.output_dir if unit.type == "folder" else None,
                    base_dir=self.config.base_dir,
                )

                # 构建 prompt
                prompt = task.build_prompt(unit, context)
                # 选择模型
                model, input_tokens = select_model(unit, task.name, self.config)

                self._print_progress(unit.id, task.name, "开始", tokens=input_tokens)

                # 调用 LLM
                output = await call_claude(
                    prompt,
                    model,
                    proxy=self.config.https_proxy,
                    dry_run=self.config.dry_run,
                    cwd=str(self.config.base_dir),
                )

                # 统计输出 token 数和行数
                output_tokens = len(_encoder.encode(output))
                output_lines = output.count("\n") + 1 if output else 0
                self.total_tokens += output_tokens

                # 写入结果
                unit.output_dir.mkdir(parents=True, exist_ok=True)
                output_path.write_text(output)

                # 更新缓存
                self.cache.mark_done(unit, task.name)

                self.completed += 1
                self._print_progress(unit.id, task.name, "完成", tokens=output_tokens, lines=output_lines, model=model)

                return TaskResult(
                    unit_id=unit.id,
                    task_name=task.name,
                    success=True,
                    output_path=output_path,
                    error=None,
                )

            except LLMError as e:
                self.failed += 1
                self._print_progress(unit.id, task.name, f"失败: {e}", tokens=0, model=model)
                return TaskResult(
                    unit_id=unit.id,
                    task_name=task.name,
                    success=False,
                    output_path=None,
                    error=str(e),
                )

            except Exception as e:
                self.failed += 1
                self._print_progress(unit.id, task.name, f"错误: {e}", tokens=0, model=model)
                return TaskResult(
                    unit_id=unit.id,
                    task_name=task.name,
                    success=False,
                    output_path=None,
                    error=str(e),
                )

    def _print_progress(
        self, unit_id: str, task_name: str, status: str, tokens: int = 0, lines: int = 0, model: str | None = None
    ):
        """打印进度"""
        done = self.completed + self.skipped + self.failed
        token_str = f"{tokens} tokens" if tokens > 0 else ""
        lines_str = f"{lines} lines" if lines > 0 else ""
        stats_str = ", ".join(filter(None, [token_str, lines_str]))
        stats_str = f" ({stats_str})" if stats_str else ""
        model_str = f" [{model}]" if model else ""
        print(f"[{done}/{self.total}][{status}] {unit_id} - {task_name}{stats_str}{model_str}")
