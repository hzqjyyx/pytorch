"""配置和核心数据结构"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from omegaconf import OmegaConf
from pydantic import BaseModel, model_validator


@dataclass
class AnalysisUnit:
    """分析单元"""

    id: str  # 唯一标识，如 "src/parser/lexer_g"
    type: Literal["file", "group", "folder"]
    files: dict[str, Path]  # {相对路径: 绝对路径}，folder 时为空
    output_dir: Path  # 输出目录
    # folder 类型专用：子单元 id 列表
    children: list[str] = field(default_factory=list)


@dataclass
class TaskResult:
    """任务执行结果"""

    unit_id: str
    task_name: str
    success: bool
    output_path: Path | None
    error: str | None


class ModelSelectionConfig(BaseModel):
    """模型选择配置"""

    # 默认模型
    default: str = "tier3"
    # token 阈值，超过该阈值使用更强模型
    token_thresholds: dict[str, int] = {
        "tier1": 10000,  # >10000 tokens 用 tier1
        "tier2": 2000,  # >2000 tokens 用 tier2
    }
    # 路径匹配覆盖，任一文件匹配则使用指定模型
    path_overrides: dict[str, list[str]] = {}  # {"tier1": ["**/main.*", "**/entry.*"]}
    # 任务类型覆盖
    task_overrides: dict[str, str] = {}  # {"folder_summary": "tier1"}


class Config(BaseModel):
    """全局配置"""

    source: Path  # 源代码目录
    target: Path  # 输出目录
    base_dir: Path | None = None  # 工作目录（默认使用 source），source 必须在此目录下
    tasks: list[str] = ["purpose"]  # 要执行的任务列表
    max_workers: int = 2  # 最大并发数
    force: bool = False  # 强制重新生成，忽略缓存
    dry_run: bool = False  # 只打印命令，不真正执行
    model_selection: ModelSelectionConfig = ModelSelectionConfig()
    exclude_patterns: list[str] = []  # 排除规则（gitignore 格式）
    https_proxy: str | None = None  # HTTPS 代理地址（可选）
    # 模型名称映射
    models: dict[str, str] = {
        "tier1": "opus",
        "tier2": "sonnet",
        "tier3": "haiku",
    }

    @model_validator(mode="after")
    def validate_paths(self) -> "Config":
        """校验路径关系"""
        # 如果未指定 base_dir，默认使用 source
        if self.base_dir is None:
            self.base_dir = self.source
            return self

        # 转为绝对路径以便比较
        base_abs = self.base_dir.resolve()
        source_abs = self.source.resolve()

        # 检查 source 是否在 base_dir 下
        try:
            source_abs.relative_to(base_abs)
        except ValueError:
            raise ValueError(f"source 目录 ({source_abs}) 必须在 base_dir ({base_abs}) 之下")

        return self


def load_config(config_path: Path | None = None, **overrides) -> Config:
    """加载配置"""
    base = {}
    if config_path and config_path.exists():
        raw = OmegaConf.load(config_path)
        base = OmegaConf.to_container(raw, resolve=True)

    # 合并命令行覆盖
    merged = {**base, **{k: v for k, v in overrides.items() if v is not None}}
    return Config(**merged)
