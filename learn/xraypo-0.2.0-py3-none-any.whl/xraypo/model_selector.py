"""模型选择逻辑"""

import fnmatch

import tiktoken

from xraypo.config import AnalysisUnit, Config

# Claude 用 cl100k_base 编码
_encoder = tiktoken.get_encoding("cl100k_base")


def estimate_tokens(unit: AnalysisUnit) -> int:
    """用 tiktoken 估算单元的 token 数"""
    total = 0
    for file_path in unit.files.values():
        if file_path.exists():
            try:
                text = file_path.read_text(errors="replace")
                total += len(_encoder.encode(text))
            except Exception:
                # 读取失败时用字符数估算
                total += file_path.stat().st_size // 4
    return total


def select_model(unit: AnalysisUnit, task_name: str, config: Config) -> str:
    """
    选择模型

    优先级：task_overrides > path_overrides > token_thresholds > default

    Returns:
        模型名称（如 "sonnet"）
    """
    ms = config.model_selection
    tokens = estimate_tokens(unit)

    # 1. 检查 task_overrides
    if task_name in ms.task_overrides:
        tier = ms.task_overrides[task_name]
        return config.models.get(tier, tier), tokens

    # 2. 检查 path_overrides
    for tier, patterns in ms.path_overrides.items():
        for pattern in patterns:
            for rel_path in unit.files.keys():
                if fnmatch.fnmatch(rel_path, pattern):
                    return config.models.get(tier, tier), tokens

    # 按阈值从大到小排序
    sorted_thresholds = sorted(ms.token_thresholds.items(), key=lambda x: -x[1])
    for tier, threshold in sorted_thresholds:
        if tokens > threshold:
            return config.models.get(tier, tier), tokens

    # 4. 返回 default
    return config.models.get(ms.default, ms.default), tokens
