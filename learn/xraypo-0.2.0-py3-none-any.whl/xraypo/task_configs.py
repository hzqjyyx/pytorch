"""任务配置类定义"""

from pydantic import BaseModel, Field


class PurposeConfig(BaseModel):
    """Purpose 任务配置"""

    prompt_template_single: str = Field(
        default="""帮我理解 {file_refs} 这个文件的主要功能。

正文忽略 ROCm 和 Backward 相关内容，结尾用 bullet-point 简单列出。
直接输出，不要开场白。""",
        description="单文件分析的 prompt 模板",
    )
    prompt_template_group: str = Field(
        default="""帮我理解 {file_refs} 这些文件的主要功能。

正文忽略 ROCm 和 Backward 相关内容，结尾用 bullet-point 简单列出。
直接输出，不要开场白。""",
        description="文件组分析的 prompt 模板",
    )


class PseudocodeConfig(BaseModel):
    """Pseudocode 任务配置"""

    prompt_file: str = Field(
        default="prompt_pseudo_aten.md",
        description="Prompt 模板文件路径（相对于任务目录或绝对路径）",
    )
    prompt_suffix: str = Field(
        default="根据以上规则，将 {file_refs} 翻译为伪代码。",
        description="Prompt 后缀模板",
    )


class FolderSummaryConfig(BaseModel):
    """FolderSummary 任务配置"""

    prompt_template: str = Field(
        default="""基于 {file_refs} 目录下的分析结果，生成该目录的汇总。

请用中文回答，包含以下内容：
1. 目录概述：这个目录的整体作用
2. 模块组成：主要包含哪些子模块，各自负责什么
3. 模块间关系：这些模块之间如何协作
4. 架构特点：有什么设计模式或架构特点
""",
        description="文件夹汇总的 prompt 模板",
    )
