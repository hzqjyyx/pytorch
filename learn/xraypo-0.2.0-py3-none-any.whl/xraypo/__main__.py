"""CLI 入口"""

import argparse
import asyncio
from pathlib import Path

from xraypo.config import load_config
from xraypo.executor import Executor
from xraypo.scanner import scan_source
from xraypo.tasks import TASK_REGISTRY, create_task


def main():
    parser = argparse.ArgumentParser(description="xraypo - LLM 代码分析工具")
    parser.add_argument("-cwd", "--base-dir", type=Path, help="工作目录（可选），用于计算相对路径引用")
    parser.add_argument("-s", "--source", type=Path, help="源代码目录")
    parser.add_argument("-t", "--target", type=Path, help="输出目录")
    parser.add_argument(
        "--tasks",
        nargs="+",
        choices=list(TASK_REGISTRY.keys()),
        help="要执行的任务列表",
    )
    parser.add_argument("-w", "--workers", type=int, default=2, help="最大并发数")
    parser.add_argument("-c", "--config", type=Path, help="配置文件路径")
    parser.add_argument("-p", "--path", type=Path, help="只分析指定的子路径")
    parser.add_argument("-f", "--force", action="store_true", help="强制重新生成，忽略缓存")
    parser.add_argument("--dry-run", action="store_true", help="只显示要执行的命令，不真正调用 LLM")
    parser.add_argument("--exclude", nargs="*", default=[], help="排除规则（gitignore 格式）")

    args = parser.parse_args()

    # 加载配置
    config = load_config(
        config_path=args.config,
        base_dir=args.base_dir,
        source=args.source,
        target=args.target,
        tasks=args.tasks,
        max_workers=args.workers,
        force=args.force,
        dry_run=args.dry_run,
        exclude_patterns=args.exclude,
    )

    print(f"Config: {config.model_dump_json(indent=2)}")

    # 扫描源码
    units = scan_source(config, target_path=args.path)
    print(f"发现 {len(units)} 个分析单元")

    file_units = [u for u in units if u.type == "file"]
    group_units = [u for u in units if u.type == "group"]
    folder_units = [u for u in units if u.type == "folder"]
    print(f"  - 单文件: {len(file_units)}")
    print(f"  - 关联组: {len(group_units)}")
    print(f"  - 文件夹: {len(folder_units)}")
    print()

    # 创建任务实例
    tasks = [create_task(task_name, config) for task_name in config.tasks]
    print(f"任务列表: {[t.name for t in tasks]}")
    print()

    # 执行分析
    executor = Executor(config, tasks)
    asyncio.run(executor.execute(units))


if __name__ == "__main__":
    main()
