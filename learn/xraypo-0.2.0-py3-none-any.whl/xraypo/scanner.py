"""源码扫描模块 - 构建分析单元"""

from collections import defaultdict
from pathlib import Path

import pathspec

from xraypo.config import AnalysisUnit, Config

# 可以组成关联组的扩展名
ASSOCIATED_EXTS = {".cpp", ".hpp", ".cu", ".h", ".c", ".cc", ".cxx", ".hxx"}

# 始终排除的目录/文件名
ALWAYS_EXCLUDE = {"__pycache__", "node_modules", ".git", ".svn", ".hg", "venv", ".venv"}


def load_gitignore(source_dir: Path) -> pathspec.PathSpec | None:
    """加载 .gitignore 规则"""
    gitignore_path = source_dir / ".gitignore"
    if not gitignore_path.exists():
        return None
    with open(gitignore_path) as f:
        return pathspec.PathSpec.from_lines("gitwildmatch", f)


def should_exclude(
    path: Path,
    source_dir: Path,
    gitignore: pathspec.PathSpec | None,
    custom_spec: pathspec.PathSpec | None,
) -> bool:
    """判断是否应该排除该路径"""
    rel_path = path.relative_to(source_dir).as_posix()

    # 始终排除隐藏文件/目录和常见无用目录
    for part in path.parts:
        if part.startswith(".") or part in ALWAYS_EXCLUDE:
            return True

    if gitignore and gitignore.match_file(rel_path):
        return True
    if custom_spec and custom_spec.match_file(rel_path):
        return True

    return False


def scan_source(config: Config, target_path: Path | None = None) -> list[AnalysisUnit]:
    """
    扫描源目录，构建分析单元列表

    Args:
        config: 配置对象
        target_path: 可选，只扫描指定的子路径
    """
    source_path = config.source.resolve()
    target_dir = config.target.resolve()

    # 如果 source 是文件，转换为目录模式
    if source_path.is_file():
        source_dir = source_path.parent
        single_file = source_path
    else:
        source_dir = source_path
        single_file = None

    # 加载排除规则
    gitignore = load_gitignore(source_dir)
    custom_spec = None
    if config.exclude_patterns:
        custom_spec = pathspec.PathSpec.from_lines("gitwildmatch", config.exclude_patterns)

    # 收集所有文件
    all_files: list[Path] = []
    all_dirs: set[Path] = set()

    # 确定扫描范围
    if single_file:
        # 如果 source 是文件，只分析这个文件
        all_files = [single_file]
        all_dirs = {single_file.parent}
    else:
        # 目录模式：递归扫描
        if target_path:
            scan_root = (source_dir / target_path).resolve()
            if not scan_root.exists():
                raise ValueError(f"目标路径不存在: {target_path}")
        else:
            scan_root = source_dir

        for path in scan_root.rglob("*"):
            if should_exclude(path, source_dir, gitignore, custom_spec):
                continue
            if path.is_file():
                all_files.append(path)
                all_dirs.add(path.parent)
            elif path.is_dir():
                all_dirs.add(path)

    # 构建关联组
    groups, single_files = _build_groups(all_files, source_dir)

    units: list[AnalysisUnit] = []

    # 创建关联组单元
    for stem, files in groups.items():
        # 用第一个文件的目录作为 id 前缀
        first_file = files[0]
        dir_rel = first_file.parent.relative_to(source_dir).as_posix()
        unit_id = f"{dir_rel}/{stem}" if dir_rel != "." else stem

        units.append(
            AnalysisUnit(
                id=unit_id,
                type="group",
                files={f.relative_to(source_dir).as_posix(): f for f in files},
                output_dir=target_dir / first_file.parent.relative_to(source_dir),
            )
        )

    # 创建单文件单元
    for file_path in single_files:
        rel_path = file_path.relative_to(source_dir).as_posix()
        unit_id = rel_path

        units.append(
            AnalysisUnit(
                id=unit_id,
                type="file",
                files={rel_path: file_path},
                output_dir=target_dir / file_path.parent.relative_to(source_dir),
            )
        )

    # 创建文件夹单元
    folder_units = _build_folder_units(all_dirs, source_dir, target_dir, units)
    units.extend(folder_units)

    return units


def _build_groups(files: list[Path], source_dir: Path) -> tuple[dict[str, list[Path]], list[Path]]:
    """
    构建关联组

    Returns:
        (关联组字典 {stem: [文件列表]}, 剩余单文件列表)
    """
    # 按 (目录, stem) 分组
    by_dir_stem: dict[tuple[Path, str], list[Path]] = defaultdict(list)
    remaining: list[Path] = []

    for f in files:
        if f.suffix.lower() in ASSOCIATED_EXTS:
            key = (f.parent, f.stem)
            by_dir_stem[key].append(f)
        else:
            remaining.append(f)

    groups: dict[str, list[Path]] = {}
    for (dir_path, stem), paths in by_dir_stem.items():
        if len(paths) > 1:
            # 多个文件组成关联组
            dir_rel = dir_path.relative_to(source_dir).as_posix()
            group_key = f"{dir_rel}/{stem}" if dir_rel != "." else stem
            groups[group_key] = sorted(paths)
        else:
            # 单独的文件回归单文件
            remaining.extend(paths)

    return groups, remaining


def _build_folder_units(
    all_dirs: set[Path],
    source_dir: Path,
    target_dir: Path,
    file_units: list[AnalysisUnit],
) -> list[AnalysisUnit]:
    """
    构建文件夹单元

    每个非空目录都生成一个 folder 单元，其 children 是该目录下直接子单元的 id
    """
    # 建立目录到子单元的映射
    dir_children: dict[str, list[str]] = defaultdict(list)

    for unit in file_units:
        # 获取单元所在目录
        if unit.type == "group":
            # group 的第一个文件所在目录
            first_file = list(unit.files.values())[0]
            parent_dir = first_file.parent
        else:
            first_file = list(unit.files.values())[0]
            parent_dir = first_file.parent

        parent_rel = parent_dir.relative_to(source_dir).as_posix()
        dir_children[parent_rel].append(unit.id)

    folder_units: list[AnalysisUnit] = []

    # 自底向上处理目录
    sorted_dirs = sorted(all_dirs, key=lambda d: -len(d.parts))

    for dir_path in sorted_dirs:
        if dir_path == source_dir:
            continue

        dir_rel = dir_path.relative_to(source_dir).as_posix()
        folder_id = f"__folder__{dir_rel}"

        # 收集直接子单元（包括子文件夹）
        children = dir_children.get(dir_rel, [])
        # 添加直接子文件夹
        for d in all_dirs:
            if d.parent == dir_path and d != dir_path:
                child_folder_id = f"__folder__{d.relative_to(source_dir).as_posix()}"
                if child_folder_id not in children:
                    children.append(child_folder_id)

        if children:
            folder_units.append(
                AnalysisUnit(
                    id=folder_id,
                    type="folder",
                    files={},  # folder 没有源文件
                    output_dir=target_dir / dir_rel,
                    children=children,
                )
            )
            # 注册到父目录
            parent_dir = dir_path.parent
            if parent_dir != source_dir.parent:
                parent_rel = parent_dir.relative_to(source_dir).as_posix()
                dir_children[parent_rel].append(folder_id)

    return folder_units
