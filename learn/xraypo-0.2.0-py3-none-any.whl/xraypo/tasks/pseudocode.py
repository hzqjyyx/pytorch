"""Pseudocode 任务 - 生成伪代码"""

import os
from pathlib import Path

from xraypo.config import AnalysisUnit
from xraypo.task_configs import PseudocodeConfig
from xraypo.tasks.base import AnalysisTask, TaskContext


class PseudocodeTask(AnalysisTask):
    """将代码翻译为伪代码"""

    name = "pseudocode"
    suffix = ".pse"

    def __init__(self, config: PseudocodeConfig):
        self.config = config
        # 处理 prompt_file 路径
        if not os.path.isabs(config.prompt_file):
            self.prompt_file = Path(__file__).parent / config.prompt_file
        else:
            self.prompt_file = Path(config.prompt_file)

    def requires_source(self) -> bool:
        return True

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        # 使用 @相对路径 语法引用文件
        if context.base_dir:
            file_refs = " ".join(
                f"@{self.relative_path(abs_path, context.base_dir)}" for abs_path in sorted(unit.files.values())
            )
        else:
            # 降级到绝对路径
            file_refs = " ".join(f"@{abs_path}" for abs_path in sorted(unit.files.values()))

        with open(self.prompt_file, "r") as f:
            aten_rule = f.read()

        suffix = self.config.prompt_suffix.format(file_refs=file_refs)
        return f"""{aten_rule}
---
{suffix}"""
