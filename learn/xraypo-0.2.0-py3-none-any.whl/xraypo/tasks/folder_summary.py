"""FolderSummary 任务 - 文件夹汇总"""

from xraypo.config import AnalysisUnit
from xraypo.task_configs import FolderSummaryConfig
from xraypo.tasks.base import AnalysisTask, TaskContext


class FolderSummaryTask(AnalysisTask):
    """基于子单元分析结果汇总文件夹"""

    name = "folder_summary"
    suffix = ".md"

    def __init__(self, config: FolderSummaryConfig):
        self.config = config

    def requires_source(self) -> bool:
        return False  # 输入是子单元的分析结果，不是源码

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        if not context.results_dir:
            return "错误：缺少子单元分析结果目录"

        # 使用 @相对路径 语法引用子单元的分析结果
        if context.base_dir:
            rel_path = self.relative_path(context.results_dir, context.base_dir)
            file_refs = f"@{rel_path}"
        else:
            # 降级到绝对路径
            file_refs = f"@{context.results_dir}"

        return self.config.prompt_template.format(file_refs=file_refs)
