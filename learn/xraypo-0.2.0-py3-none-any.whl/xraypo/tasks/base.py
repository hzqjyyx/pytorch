"""任务基类"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

from xraypo.config import AnalysisUnit


@dataclass
class TaskContext:
    """任务执行上下文"""

    # 子单元分析结果目录（folder_summary 任务使用）
    results_dir: Path | None = None
    # 工作目录基准路径（用于计算相对路径引用）
    base_dir: Path | None = None


class AnalysisTask(ABC):
    """分析任务基类"""

    name: str  # 任务名称
    suffix: str  # 输出文件后缀

    @abstractmethod
    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        """构建提示词"""
        pass

    @abstractmethod
    def requires_source(self) -> bool:
        """是否需要源码（False 表示 folder_summary 类任务）"""
        pass

    @staticmethod
    def relative_path(abs_path: Path, base_dir: Path) -> Path:
        """计算相对于 base_dir 的相对路径"""
        return abs_path.resolve().relative_to(base_dir.resolve())

    def output_filename(self, unit: AnalysisUnit) -> str:
        """生成输出文件名"""
        if unit.type == "folder":
            # 从 __folder__xxx 提取目录名
            dir_name = unit.id.replace("__folder__", "").split("/")[-1]
            return f"__folder_{dir_name}__{self.suffix}"
        elif unit.type == "group":
            # 用组名
            basename = unit.id.split("/")[-1]
            return f"{basename}{self.suffix}"
        else:
            # 单文件，在原文件名后加后缀
            filename = list(unit.files.keys())[0].split("/")[-1]
            return f"{filename}{self.suffix}"
