# PyTorch ATen 伪代码规范 (TorchPseudo DSL)

> **目标**: 将PyTorch C++/CUDA代码转换为易读的伪代码，专注于算法本质

---

## 0. 输出约束

**直接输出伪代码，禁止任何开头解释（如"Let me..."）或结尾总结（如"关键亮点..."），也不需要用 ``` 包裹。**

**处理范围**: 只处理当前文件中定义的函数。调用其他文件的函数（如 .cuh/.h）保留调用形式，不展开其实现，除非这些文件也已经被包含进你要分析的文件中。

---

## 1. 代码分类

根据代码类型选择输出格式：

| 类型 | 特征 | 模板 |
|------|------|------|
| 算法类 | Tensor操作、数学计算、kernel | 第2节 |
| 配置/管理类 | getter/setter、状态管理、全局上下文 | 第3节 |
| 工具类 | 辅助函数、类型转换、内存管理 | 第4节 |

**注意**: 一个文件可能同时包含多种类型的代码，按函数分别处理。

---

## 2. 算法类模板

### 2.1 执行位置标注

仅当函数可在 device 侧执行时才需标注：

| 标注 | 含义 |
|------|------|
| `@device` | GPU kernel，运行在 device 侧 |
| `@host→device` | host 函数，内部调用 device kernel |
| `@host` | 可在 host 侧执行，一般与 @device 配合表示函数可在两侧执行 |

纯 host 侧函数不需要标注。

### 2.2 模板格式

每个函数用以下模板：

```
--------------------------------
函数名
来源: 文件路径
--------------------------------

【签名】
    @host|@device|@host->device   (可选，见2.1)
    函数签名，使用类型注解

【算法】
    核心算法逻辑

【并行模式】(可选)
    并行策略描述

【备注】(可选)
    特殊说明
```

示例：
```
【签名】
    @device
    softmax_kernel(x: Tensor[N], y: Tensor[N])

【签名】
    @host→device
    randperm_out_cuda(n: int64, generator: Optional[Generator], result: Tensor[n]) -> Tensor[n]
```

---

## 3. 配置/管理类模板

用于 getter/setter、状态管理、全局上下文等代码。

```
--------------------------------
类名
来源: 文件路径
--------------------------------

【状态】
    字段名: 类型    # 用途说明

【接口】
    函数签名
        参数: 参数名=说明, ...   (复杂参数时使用)
        用途: 功能描述
        调用: 特定依赖的API      (该接口特有的依赖)

【依赖】(可选)
    API名称    # 用途说明
    # 列出多个接口共用的外部API依赖

【平台特定】(可选)
    平台: 特定逻辑说明
```

示例：
```
--------------------------------
Context (全局配置管理)
来源: Context.cpp
--------------------------------

【状态】
    enabled_cudnn: bool              # CuDNN 启用状态
    deterministic_algorithms: bool   # 确定性算法模式
    float32_matmul_precision: enum   # FP32矩阵乘精度 (HIGHEST|HIGH|MEDIUM)

【接口】
    userEnabledCuDNN() -> bool
        用途: 查询用户是否启用 CuDNN

    setUserEnabledCuDNN(e: bool)
        用途: 设置 CuDNN 启用状态

    setDeterministicAlgorithms(b: bool, warn_only: bool = false)
        参数: b=是否启用, warn_only=仅警告不报错
        用途: 设置全局确定性算法策略

    checkCuBLASConfigDeterministic() -> bool
        用途: 检查 CuBLAS 工作空间配置是否满足确定性要求
        调用: c10::utils::get_env(CUBLAS_WORKSPACE_CONFIG)

    blasPreferredBackend() -> BlasBackend
        用途: 获取首选 BLAS 后端，含架构检测逻辑
        调用: detail::getCUDAHooks().isGPUArch()

【依赖】
    TORCH_CHECK / TORCH_WARN    # 错误检查与警告
    c10::utils::get_env         # 环境变量读取

【平台特定】
    ROCm: hipBLASLt 架构检查 (gfx90a, gfx942)
    CUDA: CuBLAS 工作空间配置检查
```

---

## 4. 工具类模板

用于辅助函数、类型转换、内存管理等代码。

```
--------------------------------
模块描述
来源: 文件路径
--------------------------------

【函数】
    函数签名
        参数: 参数名=说明, ...   (复杂参数时使用)
        用途: 功能描述
        调用: 特定依赖的API      (该函数特有的依赖)

【依赖】(可选)
    API名称    # 用途说明
```

示例：
```
--------------------------------
内存与上下文工具
来源: Context.cpp
--------------------------------

【函数】
    getCPUAllocator() -> Allocator*
        用途: 获取全局 CPU 内存分配器
        调用: c10::GetCPUAllocator()

    globalContext() -> Context&
        用途: 获取全局单例 Context，懒初始化

    setDefaultMobileCPUAllocator()
        用途: 切换到移动端优化的 CPU 分配器
        调用: c10::SetCPUAllocator(), c10::GetDefaultMobileCPUAllocator()

【依赖】
    c10::GetCPUAllocator / SetCPUAllocator    # CPU 分配器管理
```

---

## 5. 类型系统

### 5.1 Tensor类型

```
Tensor[形状, dtype]
```

**形状语法**:
| 语法 | 含义 | 示例 |
|------|------|------|
| `N` | 具名维度 | `Tensor[B, C, H, W]` |
| `*` | 任意前缀维度 | `Tensor[*, C]` |
| `*D` | 命名的任意维度组 | `Tensor[*D, C]` |
| `?` | 可选维度 | `Tensor[?, C, H, W]` |
| `N=值` | 约束值 | `Tensor[C=3, H, W]` |

**dtype语法**: `float`, `float32`, `int`, `int64`, `bool`

### 5.2 其他类型

```
alpha: Scalar              # 任意标量
threshold: Scalar[float]   # 浮点标量
dim: int                   # 整数
mode: "none" | "tanh"      # 枚举
```

---

## 6. 算法表达

```python
# 条件
y = where(x > 0, x, x * slope)

# 数学函数
erf(x), tanh(x), exp(x), log(x), sigmoid(x), softmax(x, dim)

# 常量
PI, SQRT2, √(2/π)

# 索引
x[i], x[i:j], x[..., -1], x[indices]
x.size(0), x.dim

# 归约
max(x, dim), sum(x, dim)
```

---

## 7. 并行模式

| 模式 | 含义 |
|------|------|
| `elementwise` | 每元素独立 |
| `parallel_for i in range(N)` | 并行循环 |
| `reduce(dim, op)` | 归约操作 |
| `warp_reduce(op)` | Warp级归约 |
| `block_reduce(op)` | Block级归约 |
| `atomic_add` | 原子加 |

**注意**: 对于上表未覆盖的并行模式，使用接近原文的表达方式描述。

---

## 8. 转换原则

### 8.1 核心原则：简化但保留语义

**✅ 做**：简化语法、去除噪音、抽象类型、保留 PyTorch/CUDA 的函数调用
**❌ 不做**：展开函数调用、重写实现逻辑

```
原始代码:
    cdist_stub(device1, result, tensor1_expanded, tensor2_expanded, p);

✅ 正确 - 保留调用:
    cdist_stub(result, x1_flat, x2_flat, p)

❌ 错误 - 展开实现:
    for i in range(R1):
        for j in range(R2):
            result[i,j] = norm(x1[i] - x2[j], p)

✅ 正确 - 保留调用:
    range = at::arange(n)
❌ 错误 - 简化调用（不正确的方式）:
    range = arange(n)
```

再举一个例子
```
原始代码:
    check_inputs(XQ, WQ, x_scale, w_scale, bias, out);

    dispatch_fp8_rowwise_kernel_on_bias_dtype(XQ, WQ, x_scale, w_scale, bias, use_fast_accum, out);

✅ 正确 - 保留调用:
    check_inputs(XQ, WQ, x_scale, w_scale, bias, out)
    dispatch_fp8_rowwise_kernel_on_bias_dtype(XQ, WQ, x_scale, w_scale, bias, use_fast_accum, out);
（看起来是跟原始代码一样，但这很合理，因为就是很简单）

❌ 错误 - 展开实现:
# Step 0: 输入验证
assert XQ.is_cuda() and XQ.dtype in [float8_e4m3fn, float8_e5m2]
assert WQ.is_cuda() and WQ.dtype == float8_e4m3fn
assert x_scale.dtype == float and x_scale.shape == [M, 1]
assert w_scale.dtype == float and w_scale.shape == [1, N]
assert out.dtype == bfloat16 and out.shape == [M, N]

if bias is not None:
    assert bias.dtype in [float, bfloat16]
    assert bias.shape == [N]

# Step 1: Workaround for M不是256的倍数的padding
if M % 256 != 0:
    padded_M = ceil(M / 256) * 256
    padded_x_scale = new_empty(padded_M, 1)
    padded_x_scale[:M, :] = x_scale
    x_scale = padded_x_scale
...
```

**例外：简单 elementwise 公式**

对于纯数学的 elementwise 操作，可以直接写公式：
```
# GELU: 原始调用 GeluKernel，但公式就是核心
y = x * 0.5 * (1 + erf(x * √0.5))

# Leaky ReLU: 原始调用 leaky_relu_stub，但公式简单
y = where(x > 0, x, x * slope)
```

因为这类操作的 kernel 内部就是这个公式，没有额外逻辑。

### 8.2 忽略的内容

- `backward` 相关函数
- `#ifdef USE_ROCM` 分支
- 注册宏 (`TORCH_IMPL_FUNC`, `TORCH_META_FUNC`, `DEFINE_DISPATCH`)
- 类型分发宏本身 (`AT_DISPATCH_*`)，但如果不同类型有不同的计算策略（如 fp16 和 fp32 的累加方式不同），需要在【备注】中说明
- 错误检查 (`TORCH_CHECK`)
- 设备类型判断 (`device1 == kCPU || device1 == kCUDA`)

---

## 9. 示例

### 示例1: GELU

```
--------------------------------
gelu:
来源: Activation.cpp
--------------------------------

【签名】
    gelu(x: Tensor[*D, float], approximate: "none"|"tanh" = "none") -> Tensor[*D]

【算法】
    match approximate:
        "none":
            y = x * 0.5 * (1 + erf(x * √0.5))
        "tanh":
            β = √(2/π)
            y = x * 0.5 * (1 + tanh(β * (x + 0.044715 * x³)))

【并行模式】
    elementwise
```

### 示例2: Leaky ReLU

```
--------------------------------
leaky_relu:
来源: Activation.cpp
--------------------------------

【签名】
    leaky_relu(x: Tensor[*D], negative_slope: Scalar = 0.01) -> Tensor[*D]

【算法】
    y = where(x > 0, x, x * negative_slope)

【并行模式】
    elementwise
```

### 示例3: PReLU

```
--------------------------------
prelu:
来源: Activation.cpp
--------------------------------

【签名】
    prelu(x: Tensor[*D], weight: Tensor[1] | Tensor[C]) -> Tensor[*D]

    约束:
    - weight.numel == 1 或 weight.numel == x.size(1)
    - weight.dim <= 1

【算法】
    # 调整 weight 形状以便广播
    if x.dim != weight.dim:
        dim_w = [1] * x.dim
        if x.dim > 1:
            dim_w[1] = weight.numel
        weight = weight.reshape(dim_w)

    return _prelu_kernel(x, weight)

【备注】
    - _prelu_kernel: 实际计算 where(x > 0, x, x * weight)
```

### 示例4: SoftMax (复杂CUDA例子)

```
--------------------------------
softmax:
来源: cuda/SoftMax.cu
--------------------------------

【签名】
    softmax(x: Tensor[*, dim_size, *], dim: int) -> Tensor[*, dim_size, *]

【算法】
    # 沿 dim 维度计算 softmax
    # 将输入看作 (outer, dim_size, inner) 三维

    parallel_for outer in range(outer_size):
        parallel_for inner in range(inner_size):

            # Step 1: 找最大值 (数值稳定性)
            max_val = reduce(x[outer, :, inner], op=max)

            # Step 2: 计算 exp 和 sum
            sum_exp = reduce(exp(x[outer, :, inner] - max_val), op=sum)

            # Step 3: 归一化
            for d in range(dim_size):
                y[outer, d, inner] = exp(x[outer, d, inner] - max_val) / sum_exp

【并行模式】
    grid: (outer_size, inner_blocks)
    block: (dim_threads, inner_threads)

    - outer 维度: gridDim.x 并行
    - inner 维度: gridDim.y * blockDim.y 并行
    - dim 维度: blockDim.x 并行归约

    优化:
    - shared_memory: 存储归约中间结果
    - block_reduce: 跨 threadIdx.x 归约 max 和 sum

【备注】
    - 有两种kernel: Spatial (inner_size大) 和 Regular (dim_size大)
    - 使用 accscalar_t 进行累加以保持精度
```

### 示例5: Index Select Backward (复杂索引操作)

```
--------------------------------
indexing_backward:
来源: cuda/Indexing.cu
--------------------------------

【签名】
    indexing_backward(
        sorted_indices: Tensor[N, int64],    # 已排序
        orig_indices: Tensor[N, int64],
        grad_output: Tensor[outer, N, stride],
        accumulate: bool
    ) -> Tensor[?, stride]

【算法】
    parallel_for idx in range(N):
        # 只处理每组相同索引的第一个
        if idx == 0 or sorted_indices[idx] != sorted_indices[idx-1]:

            num_dups = count_consecutive_equal(sorted_indices, idx)
            weight_row = sorted_indices[idx]

            if not accumulate:
                # 只保留最后一个
                src_row = orig_indices[idx + num_dups - 1]
                grad_weight[weight_row, :] = grad_output[src_row, :]
            else:
                # 累加所有重复项
                for dup in range(num_dups):
                    src_row = orig_indices[idx + dup]
                    grad_weight[weight_row, :] += grad_output[src_row, :]

【并行模式】
    grid: (ceil(N/block_y), ceil(stride/warp_size), outer_dim)
    block: (warp_size, 4)

    优化:
    - 小 num_dups: 单线程顺序累加
    - 大 num_dups: warp_reduce 并行累加
```

### 示例6: cdist (成对距离计算)

```
--------------------------------
cdist_impl:
来源: Distance.cpp
--------------------------------

【签名】
    cdist_impl(
        x1: Tensor[*B, R1, C, float],    # batch可广播，R1行，C列
        x2: Tensor[*B, R2, C, float],    # batch可广播，R2行，C列
        p: float,                         # Lp范数，p >= 0
        compute_mode: 0|1|2 = 0           # 0=自动, 1=强制矩阵乘法, 2=禁用矩阵乘法
    ) -> Tensor[*B, R1, R2]

    约束:
    - x1.size(-1) == x2.size(-1)         # 列数必须相同
    - p >= 0

【算法】
    # Step 1: Batch广播并展平
    B = broadcast(x1.shape[:-2], x2.shape[:-2])
    x1_flat = x1.expand(*B, R1, C).reshape(prod(B), R1, C)
    x2_flat = x2.expand(*B, R2, C).reshape(prod(B), R2, C)

    # Step 2: 计算成对距离
    if R1 == 0 or R2 == 0 or prod(B) == 0:
        return empty(*B, R1, R2)

    if C == 0:
        return zeros(*B, R1, R2)

    if p == 2 and (mode == 1 or (mode == 0 and (R1 > 25 or R2 > 25))):
        # p=2 且行数较大时，用矩阵乘法优化
        if prod(B) == 1:
            dist = _euclidean_dist(x1, x2)
        else:
            dist = _euclidean_dist(x1_flat, x2_flat)
        result = dist.reshape(*B, R1, R2)
    else:
        # 通用 Lp 距离
        result = empty(*B, R1, R2)
        cdist_stub(result, x1_flat, x2_flat, p)
        result = result.reshape(*B, R1, R2)

    return result

【备注】
    - cdist_stub: 实际的成对距离计算kernel，见 Distance.h
    - _euclidean_dist: 欧氏距离的矩阵乘法优化实现
```
