from typing import TYPE_CHECKING

from pydantic import BaseModel

from xraypo.task_configs import FolderSummaryConfig, PseudocodeConfig, PurposeConfig
from xraypo.tasks.base import AnalysisTask, TaskContext
from xraypo.tasks.folder_summary import FolderSummaryTask
from xraypo.tasks.pseudocode import PseudocodeTask
from xraypo.tasks.purpose import PurposeTask

if TYPE_CHECKING:
    from xraypo.config import Config

# 任务注册表: {任务名: (任务类, 配置类)}
TASK_REGISTRY: dict[str, tuple[type[AnalysisTask], type[BaseModel]]] = {
    "purpose": (PurposeTask, PurposeConfig),
    "pseudocode": (PseudocodeTask, PseudocodeConfig),
    "folder_summary": (FolderSummaryTask, FolderSummaryConfig),
}


def create_task(task_name: str, config: "Config") -> AnalysisTask:
    """根据配置创建任务实例"""
    if task_name not in TASK_REGISTRY:
        raise ValueError(f"未知任务: {task_name}")

    task_class, _ = TASK_REGISTRY[task_name]
    task_config = getattr(config, task_name)
    return task_class(task_config)


__all__ = [
    "AnalysisTask",
    "TaskContext",
    "PurposeTask",
    "PurposeConfig",
    "PseudocodeTask",
    "PseudocodeConfig",
    "FolderSummaryTask",
    "FolderSummaryConfig",
    "TASK_REGISTRY",
    "create_task",
]
