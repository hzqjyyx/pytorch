"""Purpose 任务 - 分析文件作用"""

from xraypo.config import AnalysisUnit
from xraypo.task_configs import PurposeConfig
from xraypo.tasks.base import AnalysisTask, TaskContext


class PurposeTask(AnalysisTask):
    """分析文件/组的作用和目的"""

    name = "purpose"
    suffix = ".purpose.md"

    def __init__(self, config: PurposeConfig):
        self.config = config

    def requires_source(self) -> bool:
        return True

    def build_prompt(self, unit: AnalysisUnit, context: TaskContext) -> str:
        # 使用 @相对路径 语法引用文件
        if context.base_dir:
            file_refs = " ".join(
                f"@{self.relative_path(abs_path, context.base_dir)}" for abs_path in sorted(unit.files.values())
            )
        else:
            # 降级到绝对路径
            file_refs = " ".join(f"@{abs_path}" for abs_path in sorted(unit.files.values()))

        if unit.type == "file":
            return self.config.prompt_template_single.format(file_refs=file_refs)
        else:
            return self.config.prompt_template_group.format(file_refs=file_refs)
