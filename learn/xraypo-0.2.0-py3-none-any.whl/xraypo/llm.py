"""LLM 调用封装 - 使用 claude CLI"""

import asyncio
import os


class LLMError(Exception):
    """LLM 调用错误"""

    pass


BUDGET_PER_MODEL = {
    "opus": 3,
    "sonnet": 1,
    "haiku": 0.3,
}


async def call_claude(
    prompt: str,
    model: str = "haiku",
    proxy: str | None = None,
    dry_run: bool = False,
    cwd: str | None = None,
) -> str:
    """
    异步调用 claude CLI

    Args:
        prompt: 提示词
        model: 模型名称 (opus/sonnet/haiku)
        proxy: HTTPS 代理地址（可选）
        dry_run: 只打印命令，不真正执行
        cwd: 工作目录（可选），用于解析 @相对路径

    Returns:
        模型输出文本
    """
    cmd = [
        "claude",
        "-p",
        prompt,
        "--model",
        model,
        "--max-budget-usd",
        str(BUDGET_PER_MODEL[model]),
    ]

    # dry-run 模式：只打印命令
    if dry_run:
        # 截断 prompt 显示
        prompt_preview = prompt[:100].replace("\n", "\\n") + "..." if len(prompt) > 100 else prompt.replace("\n", "\\n")
        cmd_str = " ".join(cmd[:2] + [f'"{prompt_preview}"'] + cmd[3:])
        if proxy:
            cmd_str = f"HTTPS_PROXY={proxy} {cmd_str}"
        print(f"[DRY-RUN] {cmd_str}")
        return " ".join(cmd)

    # 设置环境变量
    env = os.environ.copy()
    if proxy:
        env["HTTPS_PROXY"] = proxy

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        cwd=cwd,
    )

    stdout, stderr = await proc.communicate()

    if proc.returncode != 0:
        error_msg = stderr.decode().strip() if stderr else f"Exit code {proc.returncode}"
        raise LLMError(f"claude 调用失败: {error_msg}")

    return stdout.decode()
