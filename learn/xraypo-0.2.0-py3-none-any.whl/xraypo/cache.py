"""缓存模块 - 管理 .meta.json 和增量执行"""

import hashlib
import json
from pathlib import Path
from typing import Any

from xraypo.config import AnalysisUnit

META_FILENAME = ".meta.json"
META_VERSION = 1


def compute_file_hash(path: Path) -> str:
    """计算文件 SHA256 hash"""
    sha256 = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()[:16]  # 取前 16 位足够


class CacheManager:
    """缓存管理器，负责读写 .meta.json"""

    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        self.meta_path = output_dir / META_FILENAME
        self._data: dict[str, Any] = {"version": META_VERSION, "units": {}}
        self._load()

    def _load(self):
        """加载缓存文件"""
        if self.meta_path.exists():
            with open(self.meta_path) as f:
                loaded = json.load(f)
                if loaded.get("version") == META_VERSION:
                    self._data = loaded

    def save(self):
        """保存缓存文件"""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        with open(self.meta_path, "w") as f:
            json.dump(self._data, f, indent=2)

    def should_skip(self, unit: AnalysisUnit, task_name: str, output_path: Path) -> bool:
        """判断是否应该跳过该任务"""
        # 检查输出文件是否存在
        if not output_path.exists():
            return False

        unit_cache = self._data["units"].get(unit.id)
        if not unit_cache:
            return False

        # 检查任务是否已完成
        if unit_cache.get("tasks", {}).get(task_name) != "done":
            return False

        # 检查文件 hash 是否匹配
        cached_hashes = unit_cache.get("hashes", {})
        for rel_path, abs_path in unit.files.items():
            if not abs_path.exists():
                return False
            if cached_hashes.get(rel_path) != compute_file_hash(abs_path):
                return False

        return True

    def mark_done(self, unit: AnalysisUnit, task_name: str):
        """标记任务完成"""
        if unit.id not in self._data["units"]:
            self._data["units"][unit.id] = {
                "type": unit.type,
                "hashes": {},
                "tasks": {},
            }

        unit_cache = self._data["units"][unit.id]
        # 更新 hash
        for rel_path, abs_path in unit.files.items():
            if abs_path.exists():
                unit_cache["hashes"][rel_path] = compute_file_hash(abs_path)

        unit_cache["tasks"][task_name] = "done"
        self.save()
